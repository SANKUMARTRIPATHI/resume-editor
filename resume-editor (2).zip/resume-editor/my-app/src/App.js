import React, { useState } from "react";
import axios from "axios";

const initialResume = {
  name: "John Doe",
  summary: "Experienced developer",
  experience: "Worked as a frontend developer at XYZ Company",
  education: "BCA from ABC University",
  skills: "HTML, CSS, JavaScript"
};

function App() {
  const [resume, setResume] = useState(initialResume);

  const handleChange = (field, value) => {
    setResume({ ...resume, [field]: value });
  };

  const handleEnhance = async (field) => {
    const response = await axios.post("http://localhost:8000/ai-enhance", {
      section: field,
      content: resume[field],
    });
    setResume({ ...resume, [field]: response.data.enhanced_content });
  };

  const handleSave = async () => {
    await axios.post("http://localhost:8000/save-resume", { resume });
    alert("Resume saved successfully");
  };

  const handleDownload = () => {
    const element = document.createElement("a");
    const file = new Blob([JSON.stringify(resume, null, 2)], {
      type: "application/json",
    });
    element.href = URL.createObjectURL(file);
    element.download = "resume.json";
    document.body.appendChild(element);
    element.click();
  };

  return (
    <div style={{ padding: 20 }}>
      <h1>Resume Editor</h1>
      {Object.entries(resume).map(([key, value]) => (
        <div key={key} style={{ marginBottom: 20 }}>
          <label>{key.toUpperCase()}</label>
          <textarea
            rows={3}
            style={{ width: "100%" }}
            value={value}
            onChange={(e) => handleChange(key, e.target.value)}
          />
          <button onClick={() => handleEnhance(key)}>Enhance with AI</button>
        </div>
      ))}
      <button onClick={handleSave}>Save Resume</button>
      <button onClick={handleDownload} style={{ marginLeft: 10 }}>
        Download Resume
      </button>
    </div>
  );
}

export default App;
